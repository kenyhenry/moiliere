from molieregen.cli import app
import typer

if __name__ == "__main__":
    app()